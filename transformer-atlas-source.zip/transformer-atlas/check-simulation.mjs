import assert from 'node:assert/strict';
import {readFile,readdir,access} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {resolve,dirname} from 'node:path';
import {Transformer,EXAMPLES,VOCAB} from './build/sim/model.js';
import {buildCourse,calculate,locate,hashIndex,ensureScene} from './build/sim/course.js';
import {architectureMarkup,lensMarkup,blocks,routes,blockFor} from './build/sim/architecture.js';
import {sourceInfo,lessons} from './build/data.js';

const close=(actual,expected,tolerance=1e-9,message='')=>assert.ok(Math.abs(actual-expected)<=tolerance,`${message}: ${actual} ≠ ${expected}`);
const sameMatrix=(a,b,tolerance=1e-9)=>{assert.equal(a.length,b.length);a.forEach((row,i)=>{assert.equal(row.length,b[i].length);row.forEach((v,j)=>close(v,b[i][j],tolerance));});};
const matrix=(m,id)=>m.tensors.get(id).values;
const m=new Transformer();
assert.deepEqual(matrix(m,'source.lookup'),[[.2,-.5,.8,.1],[.9,.3,-.2,.7],[-.1,.6,.4,-.8]]);
assert.deepEqual(matrix(m,'source.position')[0],[0,1,0,1]);
assert.deepEqual(matrix(m,'source.input')[0],[.4,0,1.6,1.2]);
assert.equal(m.parameterCount,963);assert.equal(m.probabilities.length,4);assert.equal(m.probabilities[0].length,15);
const q=matrix(m,'enc.0.self.h0.Q'),k=matrix(m,'enc.0.self.h0.K'),raw=matrix(m,'enc.0.self.h0.scores');
raw.forEach((r,i)=>r.forEach((v,j)=>close(v,q[i][0]*k[j][0]+q[i][1]*k[j][1])));
close(matrix(m,'enc.0.self.h0.scaled')[1][2],raw[1][2]/Math.sqrt(2));
const losses=m.targets.map((target,i)=>-Math.log(m.probabilities[i][VOCAB.indexOf(target)]));
close(m.loss,losses.reduce((a,b)=>a+b,0)/losses.length);
let checkedCells=0;
for(const t of m.trace)for(let row=0;row<t.shape[0];row++)for(let col=0;col<t.shape[1];col++){
  const c=calculate(m,t.id,row,col);assert.equal(c.result,t.values[row][col]);assert.ok(c.formula.length);
  assert.ok(!Number.isNaN(c.result),t.id);
  if(c.additive)close(c.terms.reduce((s,term)=>s+term.value,0),c.result,1e-9,t.id);
  checkedCells++;
}
for(const t of m.trace.filter(t=>t.id.endsWith('.A')&&!t.id.startsWith('backward.')))for(const [i,row]of t.values.entries()){
  close(row.reduce((s,x)=>s+x,0),1);assert.ok(row.every(x=>Number.isFinite(x)&&x>=0));
  if(t.id.startsWith('dec.')&&t.id.includes('.self.'))row.forEach((x,j)=>{if(j>i)assert.equal(x,0);});
}
for(const t of m.trace.filter(t=>t.op==='rowDivide'&&t.normalization))for(const row of t.values)close(row.reduce((a,b)=>a+b,0),0,1e-9);
console.log(`PASS: ${checkedCells} live coordinates; exact forward arithmetic and reverse chain-rule contributions; probability normalization and causal masks.`);

// Independent central finite differences validate gradients through every major sublayer.
const probes=[['source.embedding',4,1],['target.embedding',6,2],['enc.0.self.h0.WQ',0,0],['enc.1.self.h1.WV',2,1],['dec.0.cross.h0.WK',1,0],['dec.1.self.norm.gamma',0,2],['enc.0.ff.W1',0,1],['dec.1.ff.W2',3,2],['vocab.W',2,7],['vocab.bias',0,8]];
for(const [key,row,col]of probes){const p=m.parameters.get(key),initial=p.values[row][col],analytic=p.grad[row][col],epsilon=1e-5;p.values[row][col]=initial+epsilon;m.run();const plus=m.loss;p.values[row][col]=initial-epsilon;m.run();const minus=m.loss;p.values[row][col]=initial;m.run();close(analytic,(plus-minus)/(2*epsilon),2e-6,key);}
const baseline=m.probabilities.map(r=>[...r]);m.config.padding=true;m.run();sameMatrix(baseline,m.probabilities);
for(const t of m.trace.filter(t=>!t.id.startsWith('backward.')&&t.id.endsWith('.A')&&(t.id.startsWith('enc.')||t.cross)))for(const row of t.values)assert.equal(row.at(-1),0);
m.config.padding=false;m.run();const early=[...m.probabilities[0]],future=m.parameters.get('target.embedding').values[8][0];m.setParameter('target.embedding',8,0,future+.4);sameMatrix([early],[m.probabilities[0]]);
m.config.causal=false;m.run();const unmasked=[...m.probabilities[0]];m.setParameter('target.embedding',8,0,future);assert.ok(m.probabilities[0].some((v,i)=>Math.abs(v-unmasked[i])>1e-6));
for(const example of [0,1,2])for(const layers of [1,2])for(const temperature of [.3,2]){m.config={...m.config,example,layers,causal:true,temperature,attentionTemperature:temperature};m.run();assert.ok(Number.isFinite(m.loss));assert.ok([...m.paramNodes.keys()].every(key=>m.parameters.get(key).grad.flat().every(Number.isFinite)));}
console.log('PASS: 10 independent gradient probes, padding invariance, future-token isolation, and all 12 example/depth/temperature combinations.');

const trained=new Transformer(),initialLoss=trained.loss;for(let i=0;i<50;i++)trained.trainStep();assert.ok(trained.loss<initialLoss*.4);
const trainingLoss=trained.loss;trained.startGeneration();for(let i=0;i<8&&trained.generation.at(-1)!=='<eos>';i++)trained.generateNext();assert.deepEqual(trained.generation,['<bos>',...EXAMPLES[0].target]);
console.log(`PASS: 50 real SGD updates: loss ${initialLoss.toFixed(6)} → ${trainingLoss.toFixed(6)}; greedy generation: ${trained.generation.join(' ')}.`);

const model=new Transformer(),course=buildCourse(model);assert.equal(new Set(course.map(s=>s.id)).size,course.length);
assert.equal(course.length,394);assert.equal(course[0].id,'world');assert.ok(course.findIndex(s=>s.id==='problem-context')<course.findIndex(s=>s.id==='problem-recurrence'));assert.equal(course.filter(s=>s.reference).length,70);
assert.deepEqual(course.archive.filter(s=>s.reference).map(s=>s.reference),Array.from({length:70},(_,i)=>i+1));
assert.equal(lessons.length,17);assert.equal(sourceInfo.length,70);
for(const s of [...course,...course.archive]){assert.ok(s.why?.length>30,s.id);assert.ok(s.how?.length>30,s.id);assert.ok(s.result?.length>30,s.id);}
for(const s of course){assert.equal(hashIndex(course,'#'+s.id),s.index);assert.equal(locate(course,s.start+s.length*.5).index,s.index);close(locate(course,s.start+s.length*.5).local,.5);}
for(const record of model.trace){const active=blockFor(record);assert.ok(active==='all'||['source.position','target.position',...blocks.map(b=>b[0])].includes(active),record.id);assert.ok(typeof lensMarkup(record,model,{row:0,col:0})==='string');}
for(const s of course.archive){const i=ensureScene(course,s.id);assert.ok(i>=0,s.id);assert.equal(course[i].id,s.id);assert.equal(hashIndex(course,'#'+s.id),i);}
assert.equal(new Set(course.map(s=>s.id)).size,course.length);assert.equal(course.at(-1).id,'complete');
assert.ok(routes.some(([id,,target])=>id==='memory-key'&&target==='dec.cross'));assert.ok(routes.some(([id,,target])=>id==='memory-value'&&target==='dec.cross'));assert.equal(blocks.filter(b=>b[0].endsWith('.norm')).length,5);
const markup=architectureMarkup();assert.ok(markup.includes('Outputs (shifted right)'));assert.ok(markup.includes('Add &amp; Norm'));assert.ok(!/<image\b|rotate[XY]\(|webgl/i.test(markup));
console.log('PASS: 394 guided chapters with Why/How/Result, every internal step and all 70 references reachable, original encoder–decoder topology and residual/memory routes.');

const files=await readdir('build',{recursive:true});assert.ok(!files.some(f=>/\.(png|jpe?g|webp|gif|avif|pdf)$/i.test(f)));
const html=await readFile('build/index.html','utf8'),app=await readFile('build/sim/app.js','utf8');
assert.ok(!/<img\b|<image\b|<aside\b|data:image\/(png|jpeg|webp)/i.test(html));
assert.ok(html.includes('data-mode="3d"'));assert.ok(!/Source assembly|source-assets|reference-canvas/.test(html));
assert.ok(!/addEventListener\(['"]wheel/.test(app));
const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);assert.equal(new Set(ids).size,ids.length);
for(const match of app.matchAll(/\$\('([a-z-]+)'\)/g))assert.ok(ids.includes(match[1]),'Missing DOM ID '+match[1]);
for(const file of files.filter(f=>f.endsWith('.js'))){const path=resolve('build',file);execFileSync(process.execPath,['--check',path]);const source=await readFile(path,'utf8');for(const match of source.matchAll(/from\s+['"](\.[^'"]+)['"]/g))await access(resolve(dirname(path),match[1]));}
assert.ok(!files.some(f=>/^scenes\//.test(f)));
const rendererSource=await readFile('build/sim/architecture.js','utf8');assert.ok(!/loadAssembly|assemblyMarkup|source-asset|fetch\(/.test(rendererSource));
console.log('PASS: module syntax and imports, DOM wiring, native scrolling, 70 native diagram scenes, and no raster assets. Browser interaction QA is a separate gate.');

const {simulationMarkup}=await import('./build/sim/diagrams.js');for(const s of [...buildCourse(model),...course.archive]){const svg=simulationMarkup(model,s,{row:0,col:0,term:0});assert.ok(!/NaN|undefined|<image\b/.test(svg),s.id);}console.log('PASS: every scene and internal tensor has valid live vector geometry.');

const {vectorState,vectorPages,sceneMeshes,cameraMatrix}=await import('./build/sim/vector-space.js');
for(const page of vectorPages){const scene=buildCourse(model).find(s=>s.reference===page),start=vectorState(model,scene,0),end=vectorState(model,scene,1);assert.notDeepEqual(start.vectors,end.vectors,'Vectors must change independently of the camera, page '+page);for(const phase of [0,.25,.5,.75,1])for(const mesh of sceneMeshes(vectorState(model,scene,phase)))assert.ok(mesh.matrix.every(Number.isFinite));}
const analogy=vectorState(model,{reference:4,title:'analogy'},1);const find=name=>analogy.vectors.find(v=>v.name===name).to;const aunt=find('E(aunt)'),uncle=find('E(uncle)'),woman=find('E(woman)'),man=find('E(man)');aunt.forEach((v,i)=>close(v-uncle[i],woman[i]-man[i]));
const projected=vectorState(model,{reference:14,title:'projection'},1,0).vectors.find(v=>v.name==='Q · accumulated').to;model.tensors.get('enc.0.self.h0.Q').values[0].forEach((v,i)=>close((projected[i]-(i===0?1.6:.8))/1.1,v));
assert.ok([...cameraMatrix()].every(Number.isFinite));console.log('PASS: all 10 vector-space references use changing 3D geometry; analogy offsets and projection endpoints match their arithmetic.');

// The microscope must reproduce model activations, including closed ReLU gates.
{
 const {neuronState,normState}=await import('./build/sim/microscope.js');
 const model=new Transformer();let neurons=0;
 for(const t of model.tensors.values()){
  if(/^(enc|dec)\.\d+\.ff\.relu$/.test(t.id))for(let r=0;r<t.shape[0];r++)for(let j=0;j<8;j++){
   const s=neuronState(model,t.id,r,j,6);
   if(Math.abs(s.h-t.values[r][j])>1e-10||Math.abs(s.z-model.tensors.get(s.prefix+'.biased').values[r][j])>1e-10)throw Error('Neuron microscope arithmetic mismatch');
   neurons++;
  }
  if(/^(enc|dec)\.\d+\.(self|cross|ff)\.norm\.output$/.test(t.id)){
   const s=normState(model,t.id);
   if(Math.abs(s.center.reduce((a,b)=>a+b,0))>1e-10||Math.abs(s.squared.reduce((a,b)=>a+b,0)/4-s.variance)>1e-10)throw Error('Normalization microscope mismatch');
  }
 }
 console.log(`PASS: ${neurons} neuron microscopes match model activations; normalization diagrams preserve exact row statistics.`);
}

// New words receive real parameter rows; all downstream shapes and spatial outputs must follow them.
{
 const {derivation}=await import('./build/sim/math.js');
 const {liveSpatialState,canSpatial}=await import('./build/sim/live-space.js');
 const {sceneMeshes}=await import('./build/sim/vector-space.js');
 const model=new Transformer();model.setText('rain feeds rivers');
 if(model.sourceTokens.join(' ')!=='rain feeds rivers'||model.targets.join(' ')!=='rain feeds rivers <eos>')throw Error('Custom copy task mismatch');
 const first=model.tensors.get('source.input').values.map(r=>[...r]);model.setText('rivers feed rain','water flows');
 if(JSON.stringify(first)===JSON.stringify(model.tensors.get('source.input').values)||model.targetTokens.length!==3)throw Error('Custom input did not propagate');
 model.setText('天空 brightens slowly','light returns');let rendered=0;
 for(const scene of buildCourse(model)){const t=model.tensors.get(scene.tensor);if(!t)continue;
  const markup=derivation(model,calculate(model,t.id));if(!markup.includes('<math')||/NaN|undefined/.test(markup))throw Error('Invalid mathematical notation '+t.id);
  if(canSpatial(t,scene))for(const p of [0,.5,1]){const state=liveSpatialState(model,scene,p);if(sceneMeshes(state).some(mesh=>[...mesh.matrix].some(v=>!Number.isFinite(v))))throw Error('Invalid live spatial scene '+t.id);rendered++;}
 }
 const before=model.loss;for(let i=0;i<8;i++)model.trainStep();if(!Number.isFinite(model.loss)||model.loss>=before)throw Error('Custom-text training failed');
 let rejected=false;try{model.setText('one two three four five six seven');}catch{rejected=true;}if(!rejected)throw Error('Long input must have a clear readable-size limit');
 console.log(`PASS: custom Unicode text propagates through training; typeset derivations and ${rendered} spatial states remain valid.`);
}
