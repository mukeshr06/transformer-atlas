# Publish Transformer Atlas

This is a complete static frontend. No API keys, backend, account system, paid API,
package installation, or build command is required. The deployable folder is `build/`.
All scripts and styles use relative URLs and work under a GitHub project path.

## GitHub Pages

1. Create a public repository, for example `transformer-atlas`.
2. Upload the extracted project files to the repository's `main` branch. Preserve
   the `build` folder and `.github/workflows/pages.yml`; uploading only the ZIP
   does not publish a website.
3. Open Settings → Pages. Under Build and deployment, select **GitHub Actions**.
4. Open Actions → Publish Transformer Atlas → Run workflow if it has not run yet.
5. After deployment succeeds, Settings → Pages shows your public website URL.

The included workflow uploads `build/` and publishes it. Do not upload account
credentials, tokens, or environment files. None are needed by this application.

Official setup reference:
https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages

## Other static hosts

Publish the contents of `build/` as the website root. There is no server route or
build step. The application uses hash links for its one-page lesson navigation.

## Local preview

Install Node.js 20 or newer, then run:

```sh
npm run dev
```

Open the local URL printed by your server (default port 4173). ES modules should be
served over HTTP; double-clicking `index.html` through a file URL may block modules.

## Validation

```sh
npm run check
```

The checks validate arithmetic, first-order gradients, masks, training, all 70
reference scenes, custom text, mathematical markup, and finite spatial geometry.
Browser interaction and responsive rendering still need a browser check.
