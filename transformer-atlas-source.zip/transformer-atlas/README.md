# Transformer Atlas

A frontend-only, single-page Transformer learning simulation. The deployed source is
`build/`; Sites serves that directory directly. No install step, backend, login,
image textures, screenshots, traced contours, or PDF assets are required at runtime.

## Learning surface

Desktop uses 70% of the viewport for visuals and 30% for explanations and calculation
controls. The opening prompt dismisses on scrolling. Native scrolling is continuously
interpolated without wheel interception or snapping. Small screens stack the two areas.

The two-layer course has 394 scenes, including all 70 supplied diagram concepts and
every forward operation. All 688 forward/backward/learning trace entries remain
inspectable. The original Figure 1 architecture anchors the journey; individual
operations expand into native SVG token boxes, matrices, bars, nodes and connections.

## Native diagram reconstruction

`sim/reference-designs.js` and `sim/diagrams.js` define semantic frontend components
for the supplied compositions. These include subword boundaries, embedding columns,
projection matrices, column-query score grids, weighted sums, independent heads,
recurrent state propagation, conceptual context examples and architecture sublayers.
The original examples are retained where they clarify the concept. Numerical model
scenes use the current miniature; separate illustrative examples are labeled as such.
They are educational reconstructions rather than pixel-identical copies.

`sim/operation-motion.js` moves actual selected operands through products and into
result coordinates. Its running subtotal and active term stay synchronized with the
explanation panel. It also animates recurrence retention, six-token score comparisons,
parameter-count accumulation, network signals and correctly signed bar magnitudes. It does not animate
an assembled image or fade between a source picture and a live picture.

`sim/vector-space.js` handles the ten reference pages with geometric vector spaces
(3, 4, 5, 6, 8, 14, 26, 27, 28, 32). It creates real WebGL cylinder, cone and sphere
meshes, depth-tested perspective rendering, axes and grid geometry. Vectors grow,
translate or accumulate coordinate products while the default camera remains fixed.
Mouse dragging or focused-canvas arrow keys changes the camera. Touch scrolling is
preserved. If WebGL is unavailable, an explicitly labeled projected-geometry fallback
is used. Live calculation scenes also support 3D coordinate transforms, scalar heights and neural connections. Front, Top and Perspective buttons inspect the same numerical scene. The 2.5D option has been removed.

## Numerical model

The miniature has four features, two attention heads and an eight-feature feed-forward
layer. One or two blocks per encoder/decoder stack can be selected. It performs
embedding lookup/scaling, sinusoidal positions, Q/K/V projections, attention masking,
stable softmax, value mixing, head concatenation, residuals, post-layer normalization,
feed-forward layers, cross-attention, vocabulary probabilities, cross-entropy,
reverse-mode gradients and clipped SGD entirely in the browser.

The model is seeded and initially untrained. It differs from the paper's dimensions,
optimizer, dropout, label smoothing and weight tying. Conceptual analogy coordinates
and the separate six-token attention example are explicitly illustrative, not learned
semantic features or benchmark results.

## Checks

`npm run check` verifies all live arithmetic, gradient probes, causal/padding
invariants, training and generation, reachability, module/DOM wiring, 70-diagram
coverage, geometry mutation independent of camera movement, analogy offsets and
projection endpoints. Native SVG rendering covers all 60 non-spatial reference views.
The actual WebGL shaders and representative changing mesh frames were also checked
with a native OpenGL ES renderer. The managed browser preview is unavailable because
its daemon mailbox is missing; browser interaction and responsive QA remain unverified.

## Your text and mathematical derivations

The default browser example is the copy task “rain feeds rivers”. Open Your text
to enter up to six source tokens and an optional target. A blank target means copy
the source. Unicode words and punctuation are tokenized, new vocabulary entries
receive learned embeddings, and applying text resets weights. This is an untrained
teaching model, not a pretrained translator.

Equations use native MathML fractions, indices, powers, roots and summations.
Each rule is followed by live numerical substitution and a symbol explanation.
The internal-step slider synchronizes selected calculations with the visual state.
Printed values are rounded; computation retains full precision.

See [HOSTING.md](HOSTING.md) for GitHub Pages and other static hosting instructions.
The included GitHub Actions workflow publishes the `build/` directory.
